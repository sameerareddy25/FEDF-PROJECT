import React, { useState } from 'react';

export default function AuthForm({ isLoginMode, setIsLoginMode, handleAuthSubmit }) {
  const [name, setName]   = useState('');
  const [email, setEmail] = useState('');

  const onSubmit = (e) => {
    e.preventDefault();
    handleAuthSubmit({ name, email });
  };

  return (
    <div className="auth-flex-center">
      <div className="auth-card">
        <h2>{isLoginMode ? 'Welcome back 👋' : 'Create account ✨'}</h2>
        <p id="auth-desc">
          {isLoginMode
            ? 'Sign in to continue your navigation journey'
            : 'Get access to campus navigation tools'}
        </p>

        <form onSubmit={onSubmit}>
          {!isLoginMode && (
            <div>
              <label className="form-input-label">FULL NAME</label>
              <input
                type="text"
                placeholder="Your full name"
                className="form-style-input"
                value={name}
                onChange={e => setName(e.target.value)}
                required
              />
            </div>
          )}
          <label className="form-input-label">EMAIL ADDRESS</label>
          <input
            type="email"
            placeholder="you@example.com"
            className="form-style-input"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
          />

          <label className="form-input-label">PASSWORD</label>
          <input type="password" placeholder="Enter your password" className="form-style-input" required />

          <button type="submit" className="btn-pill-green-submit">
            {isLoginMode ? 'Sign In →' : 'Register Account →'}
          </button>
        </form>

        <div className="auth-divider-line"><span>or</span></div>

        <div className="toggle-footer">
          <span>{isLoginMode ? 'New here?' : 'Already have an account?'}</span>
          <button
            type="button"
            id="toggle-view-btn"
            className="btn-text-only"
            onClick={() => setIsLoginMode(!isLoginMode)}
          >
            {isLoginMode ? 'Create a free account' : 'Sign in instead'}
          </button>
        </div>
      </div>
    </div>
  );
}
