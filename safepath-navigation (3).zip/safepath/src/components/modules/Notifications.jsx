import React, { useEffect, useState } from 'react';
import { getNotifications, markAllNotificationsRead } from '../../utils/alertsStore';

function fmtAgo(iso) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr ago`;
  return `${Math.floor(hrs / 24)} day(s) ago`;
}

const SEVERITY_CLASS = {
  danger:  'notif-row-danger',
  success: 'notif-row-success',
  info:    'notif-row-info',
};

export default function Notifications({ onChange }) {
  const [list, setList] = useState([]);

  useEffect(() => {
    const refresh = () => setList(getNotifications());
    refresh();
    const interval = setInterval(refresh, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleMarkAllRead = () => {
    markAllNotificationsRead();
    setList(getNotifications());
    onChange?.();
  };

  return (
    <section className="tab-content">
      <div className="interactive-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ margin: 0 }}>🔔 Notifications</h2>
          {list.some(n => !n.read) && (
            <button className="btn-text-only" style={{ padding: '6px 10px' }} onClick={handleMarkAllRead}>
              Mark all read
            </button>
          )}
        </div>
        <p className="card-desc">
          A live feed of campus safety events — emergency alerts raised by admins and their resolutions.
        </p>

        {list.length === 0 && (
          <div className="status-box" style={{ marginTop: 12 }}>
            No notifications yet. You'll see alerts here as soon as something happens on campus.
          </div>
        )}

        {list.length > 0 && (
          <div className="notif-list">
            {list.map(n => (
              <div key={n.id} className={`notif-row ${SEVERITY_CLASS[n.severity] || 'notif-row-info'} ${n.read ? 'notif-read' : ''}`}>
                <div className="notif-row-title">{n.title}</div>
                <div className="notif-row-body">{n.body}</div>
                <div className="notif-row-time">{fmtAgo(n.createdAt)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
