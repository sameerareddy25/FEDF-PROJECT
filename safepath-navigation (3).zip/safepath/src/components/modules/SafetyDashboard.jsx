import React, { useMemo } from 'react';
import { haversine } from '../../utils/geo';
import { greetingFor } from '../../utils/sessionStore';

function fmtDist(m) {
  if (m == null) return '—';
  return m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(1)} km`;
}

/**
 * Computes a 0-100 "safety score" for the selected campus.
 * Starts at 100 and is docked per active alert — heavier for
 * alerts close to the user's live position than far-away ones,
 * since a fire on the other side of campus is less urgent to you
 * personally than one near your current path.
 */
function useSafetyScore(activeAlertCount, nearestHazardDist) {
  return useMemo(() => {
    if (activeAlertCount === 0) return 100;
    let score = 100 - activeAlertCount * 18;
    if (nearestHazardDist != null && nearestHazardDist < 150) score -= 15;
    return Math.max(5, Math.round(score));
  }, [activeAlertCount, nearestHazardDist]);
}

function scoreTone(score) {
  if (score >= 80) return { color: '#5cdb95', label: 'Safe', bg: 'rgba(92,219,149,0.12)', border: 'rgba(92,219,149,0.3)' };
  if (score >= 50) return { color: '#f5b942', label: 'Caution', bg: 'rgba(245,185,66,0.12)', border: 'rgba(245,185,66,0.3)' };
  return { color: '#ef4444', label: 'Danger', bg: 'rgba(239,68,68,0.12)', border: 'rgba(239,68,68,0.3)' };
}

export default function SafetyDashboard({
  session,
  selectedCampus,
  campusLocations = [],
  activeAlertCount = 0,
  liveLocation,
  navResult,
  onGoToNavigation,
}) {
  /* nearest hazard relative to the user's live GPS fix, computed
   * from whichever campus blocks are currently alerted/marked unsafe
   * (campusLocations doesn't carry alert state itself, so this card
   * leans on navResult.dangerBlock when a reroute is already active,
   * otherwise just reports "none" when there's nothing to show). */
  const nearestHazard = useMemo(() => {
    if (!navResult?.isSafePath || !navResult?.dangerBlock) return null;
    const block = campusLocations.find(l => l.label === navResult.dangerBlock);
    if (!block || !liveLocation) return { label: navResult.dangerBlock, distance: null };
    return {
      label: navResult.dangerBlock,
      distance: haversine(liveLocation.lat, liveLocation.lng, block.lat, block.lng),
    };
  }, [navResult, campusLocations, liveLocation]);

  const safetyScore = useSafetyScore(activeAlertCount, nearestHazard?.distance);
  const tone = scoreTone(safetyScore);

  const routesMapped = campusLocations.length;

  return (
    <div className="safety-dash">
      <div className="safety-dash-header">
        <h2>{session ? greetingFor(session) : 'Welcome'} 👋</h2>
        <p>
          {selectedCampus
            ? `Here's the live safety overview for ${selectedCampus.label}.`
            : 'Pick a campus in the Navigation tab to see live safety data.'}
        </p>
      </div>

      <div className="kpi-grid">
        {/* Safety score */}
        <div className="kpi-card" style={{ background: tone.bg, borderColor: tone.border }}>
          <div className="kpi-icon">🛡️</div>
          <div className="kpi-value" style={{ color: tone.color }}>{safetyScore}<span className="kpi-unit">/100</span></div>
          <div className="kpi-label">Safety Score</div>
          <div className="kpi-sub" style={{ color: tone.color }}>{tone.label}</div>
        </div>

        {/* Active alerts */}
        <div className={`kpi-card ${activeAlertCount > 0 ? 'kpi-card-danger' : ''}`}>
          <div className="kpi-icon">{activeAlertCount > 0 ? '🚨' : '✅'}</div>
          <div className="kpi-value">{activeAlertCount}</div>
          <div className="kpi-label">Active Alerts</div>
          <div className="kpi-sub">{activeAlertCount > 0 ? 'Needs attention' : 'All clear'}</div>
        </div>

        {/* Routes mapped */}
        <div className="kpi-card">
          <div className="kpi-icon">🗺️</div>
          <div className="kpi-value">{routesMapped}</div>
          <div className="kpi-label">Routes Mapped</div>
          <div className="kpi-sub">{selectedCampus ? `${selectedCampus.label} blocks` : 'No campus selected'}</div>
        </div>

        {/* Nearest hazard */}
        <div className={`kpi-card ${nearestHazard ? 'kpi-card-danger' : ''}`}>
          <div className="kpi-icon">{nearestHazard ? '📍' : '🟢'}</div>
          <div className="kpi-value" style={{ fontSize: nearestHazard ? '1.3rem' : undefined }}>
            {nearestHazard ? fmtDist(nearestHazard.distance) : 'None'}
          </div>
          <div className="kpi-label">Nearest Hazard</div>
          <div className="kpi-sub">{nearestHazard ? nearestHazard.label : 'No danger zones nearby'}</div>
        </div>
      </div>

      <div className="safety-dash-cta">
        {activeAlertCount > 0 ? (
          <div className="dash-banner dash-banner-danger">
            <span>🚨</span>
            <div>
              <strong>{activeAlertCount} active alert{activeAlertCount > 1 ? 's' : ''}</strong> in this campus.
              Navigation will automatically reroute you away from danger zones.
            </div>
          </div>
        ) : (
          <div className="dash-banner dash-banner-safe">
            <span>🟢</span>
            <div>No danger reported right now — every mapped route is currently clear and safe to use.</div>
          </div>
        )}
        <button className="btn-pill-outline" style={{ marginTop: 14 }} onClick={onGoToNavigation}>
          Go to Live Navigation →
        </button>
      </div>
    </div>
  );
}
