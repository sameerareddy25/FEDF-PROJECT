import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { getBlockIcon } from '../../data/constants';

/* ── fix default Leaflet marker icons (vite / webpack issue) ── */
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

function makeLiveIcon() {
  return L.divIcon({
    className: '',
    html: `<div style="
      width:16px;height:16px;border-radius:50%;
      background:#ff3b30;border:3px solid #fff;
      box-shadow:0 0 10px rgba(255,59,48,0.8);
      animation:livePulse 1.1s ease-in-out infinite"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
  });
}

function makeDestIcon() {
  return L.divIcon({
    className: '',
    html: `<div style="position:relative;width:26px;height:36px">
      <svg viewBox="0 0 26 36" xmlns="http://www.w3.org/2000/svg">
        <path d="M13 0C5.8 0 0 5.8 0 13c0 9.1 13 23 13 23s13-13.9 13-23C26 5.8 20.2 0 13 0z" fill="#e74c3c"/>
        <circle cx="13" cy="13" r="5.5" fill="white"/>
      </svg></div>`,
    iconSize: [26, 36],
    iconAnchor: [13, 36],
    popupAnchor: [0, -36],
  });
}

function makeBlockIcon(label, isDanger) {
  const emoji = isDanger ? '🚨' : getBlockIcon(label);
  const bg     = isDanger ? '#3a1414' : '#143a2f';
  const border = isDanger ? '#ef4444' : '#5cdb95';
  const color  = isDanger ? '#ff8080' : '#5cdb95';
  return L.divIcon({
    className: '',
    html: `<div style="
      background:${bg};border:1.5px solid ${border};
      border-radius:8px;padding:3px 6px;
      font-size:0.75rem;color:${color};font-weight:700;
      white-space:nowrap;box-shadow:0 2px 6px rgba(0,0,0,0.4);
      font-family:Segoe UI,Arial,sans-serif;
      ${isDanger ? 'animation:livePulse 1.1s ease-in-out infinite;' : ''}">
      ${emoji} ${label}</div>`,
    iconAnchor: [0, 0],
  });
}

/* ═════════════════════════════════════════════════════════════ */
export default function MapView({ selectedCampus, campusLocations, liveLocation, destinationNode, navResult, tracking, onToggleTracking, alertedBlocks = [] }) {
  const containerRef    = useRef(null);
  const mapRef          = useRef(null);
  const blockLayerRef   = useRef(null);
  const routeLayerRef   = useRef(null);
  const destMarkerRef   = useRef(null);
  const liveMarkerRef   = useRef(null);
  const hasCenteredRef  = useRef(false);

  /* ── init map once ─────────────────────────────── */
  useEffect(() => {
    if (mapRef.current || !containerRef.current) return;

    const map = L.map(containerRef.current, {
      center: [20.5937, 78.9629], // sensible default before we know anything
      zoom: 5,
      zoomControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
    }).addTo(map);

    blockLayerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  /* ── center on campus once selected ────────────── */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !selectedCampus) return;
    map.setView([selectedCampus.lat, selectedCampus.lng], 16);
    setTimeout(() => map.invalidateSize(), 120);
  }, [selectedCampus]);

  /* ── redraw campus block markers ───────────────── */
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    blockLayerRef.current?.clearLayers();

    if (selectedCampus) {
      campusLocations.forEach(loc => {
        if (!loc.lat || !loc.lng) return;
        const isDanger = alertedBlocks.some(b => b.toLowerCase() === loc.label.toLowerCase());
        L.marker([loc.lat, loc.lng], { icon: makeBlockIcon(loc.label, isDanger) })
          .bindPopup(isDanger
            ? `<b style="color:#ef4444">🚨 ${loc.label}</b><br/><span style="color:#ef4444">Active emergency alert — unsafe</span>`
            : `<b>${getBlockIcon(loc.label)} ${loc.label}</b>`)
          .addTo(blockLayerRef.current);
      });
    }

    setTimeout(() => map.invalidateSize(), 120);
  }, [selectedCampus, campusLocations, alertedBlocks]);

  /* ── live "you are here" marker, updates as it moves ─ */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !liveLocation) return;

    if (!liveMarkerRef.current) {
      liveMarkerRef.current = L.marker([liveLocation.lat, liveLocation.lng], { icon: makeLiveIcon(), zIndexOffset: 500 })
        .bindPopup('📡 You are here')
        .addTo(map);
    } else {
      liveMarkerRef.current.setLatLng([liveLocation.lat, liveLocation.lng]);
    }

    if (!hasCenteredRef.current && !selectedCampus) {
      map.setView([liveLocation.lat, liveLocation.lng], 15);
      hasCenteredRef.current = true;
    }

    if (tracking) {
      map.panTo([liveLocation.lat, liveLocation.lng], { animate: true, duration: 0.6 });
    }
  }, [liveLocation, tracking, selectedCampus]);

  /* ── destination marker + route polyline ───────── */
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    destMarkerRef.current?.remove();
    routeLayerRef.current?.remove();
    destMarkerRef.current = null;
    routeLayerRef.current = null;

    const dest = campusLocations.find(l => l.label === destinationNode);
    if (dest) {
      destMarkerRef.current = L.marker([dest.lat, dest.lng], { icon: makeDestIcon(), zIndexOffset: 200 })
        .bindPopup(`<b>📍 Destination</b><br>${dest.label}`)
        .addTo(map);
    }

    if (navResult?.geometry?.length) {
      routeLayerRef.current = L.polyline(navResult.geometry, {
        color: navResult.isSafePath ? '#ef4444' : '#5cdb95',
        weight: 6,
        opacity: 0.95,
        dashArray: navResult.isSafePath ? '4 8' : (navResult.live ? null : '12 6'),
        lineCap: 'round',
      }).addTo(map);

      const bounds = L.latLngBounds(navResult.geometry);
      if (liveLocation) bounds.extend([liveLocation.lat, liveLocation.lng]);
      map.fitBounds(bounds, { padding: [60, 60] });
    } else if (dest) {
      map.setView([dest.lat, dest.lng], 17);
    }

    setTimeout(() => map.invalidateSize(), 120);
  }, [destinationNode, campusLocations, navResult]);

  const overlayStep = navResult?.steps?.find(s => s.type === 'walk' || s.type === 'turn');

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>

      {navResult && overlayStep && (
        <div className={`nav-overlay ${navResult.isSafePath ? 'nav-overlay-danger' : ''}`}>
          <div className="nav-overlay-arrow">{overlayStep.icon}</div>
          <div className="nav-overlay-body">
            <div className="nav-overlay-main">{overlayStep.text}</div>
            <div className="nav-overlay-sub">{overlayStep.sub}</div>
          </div>
          <div className="nav-overlay-dist">
            <strong>{navResult.distance}</strong>
            <span>{navResult.duration}</span>
          </div>
        </div>
      )}

      <div ref={containerRef} style={{ width: '100%', height: '100%', minHeight: 400 }} />

      {destinationNode && (
        <button
          className={`live-track-btn ${tracking ? 'tracking-on' : ''}`}
          onClick={onToggleTracking}
        >
          <span className="live-pulse" />
          {tracking ? 'Stop Live Navigation' : 'Start Live Navigation'}
        </button>
      )}
    </div>
  );
}
