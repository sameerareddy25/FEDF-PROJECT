import React from 'react';

export default function RoutePanel({
  selectedCampus,
  locations,
  destinationNode,
  liveLocation,
  onDestinationChange,
  onGetDirections,
  alertedBlocks = [],
}) {
  if (!selectedCampus) return null;

  const noDestination = !destinationNode;
  const destIsDanger = destinationNode && alertedBlocks.some(
    b => b.toLowerCase() === destinationNode.toLowerCase()
  );

  return (
    <div className="route-panel-section">
      <p className="nl-section-label">🧭 Live Navigation</p>

      <div className="route-inputs-wrap">
        <div className="route-connector" />

        {/* From — always the user's live GPS position */}
        <div className="route-input-row">
          <div className="route-dot rd-origin" />
          <div className="route-node-select route-node-readonly">
            📡 {liveLocation ? 'Your Live Location' : 'Waiting for GPS…'}
          </div>
        </div>

        {/* To */}
        <div className="route-input-row" style={{ marginBottom: 0 }}>
          <div className="route-dot rd-dest" />
          <select
            className="route-node-select"
            value={destinationNode || ''}
            onChange={e => onDestinationChange(e.target.value)}
          >
            <option value="" disabled>Select a block…</option>
            {locations.map(l => (
              <option key={l.label} value={l.label}>
                {alertedBlocks.some(b => b.toLowerCase() === l.label.toLowerCase()) ? `🚨 ${l.label} (alert active)` : l.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {destIsDanger && (
        <div className="status-box status-box-danger" style={{ marginTop: 10 }}>
          🚨 {destinationNode} has an active emergency alert. You'll be guided to a safe
          path back to the main gate instead.
        </div>
      )}

      <button
        className={`get-directions-btn ${destIsDanger ? 'get-directions-btn-danger' : ''}`}
        onClick={onGetDirections}
        disabled={noDestination || !liveLocation}
        title={noDestination ? 'Select a destination block first' : 'Get live directions'}
      >
        {noDestination
          ? '⚠️ Choose a destination block'
          : destIsDanger
            ? '🛟 Get Safe Path to Main Gate'
            : '🧭 Start Live Navigation'}
      </button>
    </div>
  );
}
