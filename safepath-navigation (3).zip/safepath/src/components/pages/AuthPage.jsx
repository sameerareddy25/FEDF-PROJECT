import React from 'react';
import Header from '../Header';
import AuthForm from '../AuthForm';

export default function AuthPage({ view, openPublicHome, isLoginMode, setIsLoginMode, handleAuthSubmit }) {
  return (
    <div id="auth-page" className={view !== 'auth' ? 'hidden' : ''}>
      <Header view={view} openPublicHome={openPublicHome} setIsLoginMode={setIsLoginMode} />
      <AuthForm
        isLoginMode={isLoginMode}
        setIsLoginMode={setIsLoginMode}
        handleAuthSubmit={handleAuthSubmit}
      />
    </div>
  );
}
