import React, { useState } from 'react';
import Header from '../Header';
import Sidebar from '../Sidebar';
import NavigationModule from '../navigation/NavigationModule';
import EmergencyAlerts from '../modules/EmergencyAlerts';
import Notifications from '../modules/Notifications';
import AdminDashboard from '../modules/AdminDashboard';
import AdminLoginGate from '../modules/AdminLoginGate';
import SafetyDashboard from '../modules/SafetyDashboard';

export default function DashboardPage({
  view,
  openPublicHome,
  session,
  onLogout,
  query,
  onQueryChange,
  suggestions,
  selectedCampus,
  locating,
  locationError,
  searchLoading,
  hasSearched,
  nearbyCount,
  campusLocations,
  blocksLoading,
  liveLocation,
  destinationNode,
  navResult,
  tracking,
  alertedBlocks,
  activeAlertCount,
  unreadCount,
  isAdmin,
  onCampusSelect,
  onCampusClear,
  onDestinationChange,
  onBlockClick,
  onGetDirections,
  onToggleTracking,
  onBlocksChanged,
  onNotificationsChanged,
  onAdminLoginSuccess,
  onAdminLogout,
}) {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div id="main-app" className={view !== 'main' ? 'hidden' : ''}>
      <Header view={view} openPublicHome={openPublicHome} session={session} onLogout={onLogout} />

      <div className="dashboard-container">
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isAdmin={isAdmin}
          unreadCount={unreadCount}
          activeAlertCount={activeAlertCount}
        />

        {/* content area – no padding so map fills edge-to-edge on navigation tab */}
        <main id="content-area">
          {activeTab === 'dashboard' && (
            <div className="scrollable-tab-area">
              <SafetyDashboard
                session={session}
                selectedCampus={selectedCampus}
                campusLocations={campusLocations}
                activeAlertCount={activeAlertCount}
                liveLocation={liveLocation}
                navResult={navResult}
                onGoToNavigation={() => setActiveTab('navigation')}
              />
            </div>
          )}

          {activeTab === 'navigation' && (
            <NavigationModule
              query={query}
              onQueryChange={onQueryChange}
              suggestions={suggestions}
              selectedCampus={selectedCampus}
              locating={locating}
              locationError={locationError}
              searchLoading={searchLoading}
              hasSearched={hasSearched}
              nearbyCount={nearbyCount}
              campusLocations={campusLocations}
              blocksLoading={blocksLoading}
              liveLocation={liveLocation}
              destinationNode={destinationNode}
              navResult={navResult}
              tracking={tracking}
              alertedBlocks={alertedBlocks}
              onCampusSelect={onCampusSelect}
              onCampusClear={onCampusClear}
              onDestinationChange={onDestinationChange}
              onBlockClick={onBlockClick}
              onGetDirections={onGetDirections}
              onToggleTracking={onToggleTracking}
            />
          )}

          {activeTab === 'alerts' && (
            <div className="scrollable-tab-area">
              <EmergencyAlerts selectedCampus={selectedCampus} />
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="scrollable-tab-area">
              <Notifications onChange={onNotificationsChanged} />
            </div>
          )}

          {activeTab === 'admin' && (
            <div className="scrollable-tab-area">
              {isAdmin ? (
                <AdminDashboard
                  selectedCampus={selectedCampus}
                  onBlocksChanged={onBlocksChanged}
                />
              ) : (
                <AdminLoginGate onSuccess={onAdminLoginSuccess} />
              )}
              {isAdmin && (
                <div style={{ padding: '0 18px 18px' }}>
                  <button className="btn-logout" onClick={onAdminLogout}>Exit Admin Mode</button>
                </div>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
