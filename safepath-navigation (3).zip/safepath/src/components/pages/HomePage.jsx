import React from 'react';
import Header from '../Header';

export default function HomePage({ view, openLoginView }) {
  return (
    <div id="public-homepage" className={view !== 'home' ? 'hidden' : ''}>
      <Header view={view} openLoginView={openLoginView} />

      <section className="landing-hero-section">
        <div className="hero-typography">
          <h1 className="accent-title">
            Locate.<br />
            <span className="italic-title">Navigate.</span><br />
            Arrive.
          </h1>
          <p className="hero-description">
            A smart campus navigation tool. Select your campus, pick your destination block,
            and follow turn-by-turn directions — just like Google Maps, built for your campus.
          </p>
          <div className="hero-action-row">
            <button className="btn-pill-white" onClick={openLoginView}>Get Started</button>
          </div>
        </div>

        <div className="hero-metrics-row">
          <div className="metric-item">
            <div className="metric-num">2</div>
            <div className="metric-label">Campus zones</div>
          </div>
          <div className="metric-item">
            <div className="metric-num">20+</div>
            <div className="metric-label">Mapped blocks</div>
          </div>
          <div className="metric-item">
            <div className="metric-num">Live</div>
            <div className="metric-label">GPS tracking</div>
          </div>
        </div>
      </section>

      <section className="workflow-section">
        <span className="section-tag-label">HOW IT WORKS</span>
        <h2 className="workflow-title">Simple as <em>1 – 2 – 3</em></h2>
        <p className="workflow-subtitle">
          No complex setup. Just choose your campus, select a destination block, and go.
        </p>

        <div className="workflow-cards-grid">
          <div className="step-process-card">
            <div className="step-number">01</div>
            <div className="step-emoji">🏫</div>
            <h3>Select Your Campus</h3>
            <p>Choose from Main Campus or North Campus. All available blocks load instantly.</p>
          </div>
          <div className="step-process-card">
            <div className="step-number">02</div>
            <div className="step-emoji">📍</div>
            <h3>Pick Origin &amp; Destination</h3>
            <p>Tap any block card to set your destination. Choose your starting point from the list.</p>
          </div>
          <div className="step-process-card">
            <div className="step-number">03</div>
            <div className="step-emoji">🗺️</div>
            <h3>Follow Turn-by-Turn Directions</h3>
            <p>The map draws your route and the left panel shows step-by-step walking directions.</p>
          </div>
          <div className="step-process-card">
            <div className="step-number">04</div>
            <div className="step-emoji">📡</div>
            <h3>Enable Live GPS Tracking</h3>
            <p>Hit "Start Live Navigation" to track your real-time position on the campus map.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
