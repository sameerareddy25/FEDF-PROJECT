/* ─── Simple Admin flag ─────────────────────────────────────────
 * A lightweight, separate "Admin Mode" login distinct from the
 * normal user Sign In. Not meant to be production-grade security
 * — just enough to gate the Admin Dashboard tab behind a passcode
 * so random users can't raise fire alerts or edit blocks.
 * ──────────────────────────────────────────────────────────── */

const ADMIN_FLAG_KEY = 'safepath_is_admin_v1';
const ADMIN_PASSCODE = 'admin123'; // change this for your real deployment

export function isAdmin() {
  try {
    return sessionStorage.getItem(ADMIN_FLAG_KEY) === 'true';
  } catch {
    return false;
  }
}

export function tryAdminLogin(passcode) {
  if (passcode === ADMIN_PASSCODE) {
    try { sessionStorage.setItem(ADMIN_FLAG_KEY, 'true'); } catch { /* ignore */ }
    return true;
  }
  return false;
}

export function adminLogout() {
  try { sessionStorage.removeItem(ADMIN_FLAG_KEY); } catch { /* ignore */ }
}
