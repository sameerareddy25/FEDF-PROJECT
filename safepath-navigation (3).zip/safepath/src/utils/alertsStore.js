/* ─── Emergency alerts + notification feed ─────────────────────
 * An Admin can raise a fire/accident alert on a specific block of
 * a campus. While active, any user navigating in that campus sees
 * a danger banner, and if their route would pass through (or end
 * at) the alerted block, the route is redirected toward campus
 * safety — i.e. away from the danger block, back to the Main
 * Gate / Entrance. Every raise/clear also drops a Notification
 * entry so users can see a history feed.
 * ──────────────────────────────────────────────────────────── */

const ALERTS_KEY        = 'safepath_alerts_v1';
const NOTIFICATIONS_KEY = 'safepath_notifications_v1';

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
function writeJSON(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore */ }
}

/* ── Alerts ──────────────────────────────────────────────────── */

/** All alerts (active + cleared) across every campus. */
export function getAllAlerts() {
  return readJSON(ALERTS_KEY, []);
}

/** Active (uncleared) alerts for one campus. */
export function getActiveAlertsForCampus(campusId) {
  return getAllAlerts().filter(a => a.campusId === campusId && !a.clearedAt);
}

/** Is this specific block currently under an active alert? */
export function isBlockAlerted(campusId, blockLabel) {
  return getActiveAlertsForCampus(campusId).some(
    a => a.blockLabel.toLowerCase() === blockLabel.toLowerCase()
  );
}

/** Raise a new emergency alert on a block. */
export function raiseAlert({ campusId, campusLabel, blockLabel, type = 'fire', note = '' }) {
  const alerts = getAllAlerts();
  const alert = {
    id: `alert_${Date.now()}`,
    campusId,
    campusLabel,
    blockLabel,
    type,            // 'fire' | 'accident' | 'other'
    note,
    raisedAt: new Date().toISOString(),
    clearedAt: null,
  };
  writeJSON(ALERTS_KEY, [alert, ...alerts]);

  pushNotification({
    kind: 'alert_raised',
    title: `🚨 ${type === 'fire' ? 'Fire' : type === 'accident' ? 'Accident' : 'Emergency'} reported at ${blockLabel}`,
    body: `${campusLabel}: ${blockLabel} is unsafe. Navigation is rerouting users toward the main gate.`,
    severity: 'danger',
  });

  return alert;
}

/** Clear (resolve) an active alert. */
export function clearAlert(alertId) {
  const alerts = getAllAlerts();
  const updated = alerts.map(a =>
    a.id === alertId ? { ...a, clearedAt: new Date().toISOString() } : a
  );
  writeJSON(ALERTS_KEY, updated);

  const cleared = updated.find(a => a.id === alertId);
  if (cleared) {
    pushNotification({
      kind: 'alert_cleared',
      title: `✅ ${cleared.blockLabel} is now safe`,
      body: `${cleared.campusLabel}: the alert at ${cleared.blockLabel} has been resolved.`,
      severity: 'success',
    });
  }
  return updated;
}

/* ── Notifications feed ─────────────────────────────────────── */

export function getNotifications() {
  return readJSON(NOTIFICATIONS_KEY, []);
}

export function pushNotification({ kind, title, body, severity = 'info' }) {
  const list = getNotifications();
  const note = {
    id: `note_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    kind,
    title,
    body,
    severity,        // 'danger' | 'success' | 'info'
    createdAt: new Date().toISOString(),
    read: false,
  };
  writeJSON(NOTIFICATIONS_KEY, [note, ...list].slice(0, 50)); // keep last 50
  return note;
}

export function markAllNotificationsRead() {
  const list = getNotifications().map(n => ({ ...n, read: true }));
  writeJSON(NOTIFICATIONS_KEY, list);
  return list;
}

export function unreadNotificationCount() {
  return getNotifications().filter(n => !n.read).length;
}
