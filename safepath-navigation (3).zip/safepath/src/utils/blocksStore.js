/* ─── Locally-saved campus blocks (admin-managed) ──────────────
 * OpenStreetMap rarely has named buildings like "ECE Block" or
 * "Hostel" tagged for most Indian college campuses. So besides
 * pulling whatever OSM does have, we let an Admin manually add /
 * edit / remove named blocks for each campus. They're saved in
 * the browser's localStorage, keyed by campus id, and merged
 * with the live OSM result every time a campus is opened.
 * ──────────────────────────────────────────────────────────── */

const STORAGE_KEY = 'safepath_custom_blocks_v1';

function readAll() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function writeAll(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    /* storage might be full / disabled — fail silently */
  }
}

/** Get the custom (admin-added) blocks saved for a given campus id. */
export function getCustomBlocks(campusId) {
  const all = readAll();
  return all[campusId] || [];
}

/** Replace the entire custom-blocks list for a campus. */
export function saveCustomBlocks(campusId, blocks) {
  const all = readAll();
  all[campusId] = blocks;
  writeAll(all);
}

/** Add one new block to a campus (auto-generates an id). */
export function addCustomBlock(campusId, block) {
  const list = getCustomBlocks(campusId);
  const newBlock = { ...block, id: block.id || `custom_${Date.now()}` };
  const updated = [...list, newBlock];
  saveCustomBlocks(campusId, updated);
  return updated;
}

/** Update one existing custom block by id. */
export function updateCustomBlock(campusId, blockId, patch) {
  const list = getCustomBlocks(campusId);
  const updated = list.map(b => (b.id === blockId ? { ...b, ...patch } : b));
  saveCustomBlocks(campusId, updated);
  return updated;
}

/** Remove one custom block by id. */
export function removeCustomBlock(campusId, blockId) {
  const list = getCustomBlocks(campusId);
  const updated = list.filter(b => b.id !== blockId);
  saveCustomBlocks(campusId, updated);
  return updated;
}

/**
 * Merge OSM-fetched blocks with admin custom blocks for a campus.
 * Custom blocks win on name clashes (admin can override OSM names).
 */
export function mergeBlocks(osmBlocks, customBlocks) {
  const seen = new Set();
  const merged = [];

  customBlocks.forEach(b => {
    const key = b.label.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    merged.push({ label: b.label, lat: b.lat, lng: b.lng, id: b.id, custom: true });
  });

  osmBlocks.forEach(b => {
    const key = b.label.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    merged.push({ label: b.label, lat: b.lat, lng: b.lng, custom: false });
  });

  return merged;
}
