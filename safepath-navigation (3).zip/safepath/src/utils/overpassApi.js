/* ─── OpenStreetMap Overpass API helpers ──────────────────────
 * Free, no API key required. We use it to:
 *   1. find real colleges / universities near the user's live location
 *   2. find the real mapped buildings ("blocks") inside a chosen campus
 * ──────────────────────────────────────────────────────────── */

const OVERPASS_ENDPOINTS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
];

async function runOverpassQuery(query) {
  let lastErr;
  for (const endpoint of OVERPASS_ENDPOINTS) {
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        body: 'data=' + encodeURIComponent(query),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (!res.ok) throw new Error(`Overpass error ${res.status}`);
      return await res.json();
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr || new Error('All Overpass endpoints failed');
}

function centerOf(el) {
  if (el.type === 'node') return { lat: el.lat, lng: el.lon };
  if (el.center) return { lat: el.center.lat, lng: el.center.lon };
  return null;
}

/**
 * Search real colleges / universities near a live lat/lng.
 * radius is in meters (default 20km).
 */
export async function searchNearbyCampuses(lat, lng, radius = 20000) {
  const query = `
    [out:json][timeout:25];
    (
      nwr["amenity"="university"](around:${radius},${lat},${lng});
      nwr["amenity"="college"](around:${radius},${lat},${lng});
    );
    out center tags;
  `;

  const data = await runOverpassQuery(query);
  const seen = new Set();
  const campuses = [];

  for (const el of data.elements || []) {
    const name = el.tags?.name;
    const c = centerOf(el);
    if (!name || !c) continue;
    const key = name.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);

    campuses.push({
      id: `${el.type}/${el.id}`,
      label: name,
      lat: c.lat,
      lng: c.lng,
      distance: haversineMeters(lat, lng, c.lat, c.lng),
    });
  }

  campuses.sort((a, b) => a.distance - b.distance);
  return campuses;
}

/**
 * Fetch real mapped buildings inside / around a chosen campus to use as
 * navigable "blocks". Falls back to an empty list if OSM has nothing mapped.
 */
export async function fetchCampusBuildings(campus, radius = 600) {
  const query = `
    [out:json][timeout:25];
    (
      nwr["building"]["name"](around:${radius},${campus.lat},${campus.lng});
      nwr["amenity"]["name"](around:${radius},${campus.lat},${campus.lng});
    );
    out center tags;
  `;

  const data = await runOverpassQuery(query);
  const seen = new Set();
  const blocks = [];

  for (const el of data.elements || []) {
    const name = el.tags?.name;
    const c = centerOf(el);
    if (!name || !c) continue;
    if (name.toLowerCase() === campus.label.toLowerCase()) continue;
    const key = name.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);

    blocks.push({ label: name, lat: c.lat, lng: c.lng });
  }

  return blocks;
}

function haversineMeters(lat1, lng1, lat2, lng2) {
  const R = 6371e3;
  const p1 = (lat1 * Math.PI) / 180;
  const p2 = (lat2 * Math.PI) / 180;
  const dp = ((lat2 - lat1) * Math.PI) / 180;
  const dl = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dp / 2) ** 2 +
    Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
